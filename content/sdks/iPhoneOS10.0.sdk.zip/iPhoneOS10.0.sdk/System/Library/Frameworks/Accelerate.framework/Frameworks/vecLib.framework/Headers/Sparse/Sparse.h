/*  Copyright (c) 2014 Apple Inc.  All rights reserved.                       */

#ifndef __SPARSE_HEADER__
#define __SPARSE_HEADER__

#include <vecLib/Sparse/Types.h>
#include <vecLib/Sparse/BLAS.h>

#endif
  /* __SPARSE_HEADER__ */
